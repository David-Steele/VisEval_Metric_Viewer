package beer.learning

/**
 * @author milos
 */
trait OutputScaler {
  
  def scale(x:Double) : Double
  
}