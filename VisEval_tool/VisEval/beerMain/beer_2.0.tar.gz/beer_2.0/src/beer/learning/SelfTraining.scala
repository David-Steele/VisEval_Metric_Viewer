package beer.learning

class SelfTraining {
  
}