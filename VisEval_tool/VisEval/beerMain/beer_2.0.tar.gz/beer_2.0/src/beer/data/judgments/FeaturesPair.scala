package beer.data.judgments

class FeaturesPair (
    val winner: Array[Double],
    val loser : Array[Double]
    )
