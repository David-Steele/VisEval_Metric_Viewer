package beer.data.judgments

class NonMappedFeaturesPair (
    val winner: List[(String, Double)],
    val loser : List[(String, Double)]
    )
    